#!/bin/sh

exec /main -g -p $1
