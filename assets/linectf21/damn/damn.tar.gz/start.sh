
#!/bin/sh
# Add your startup script

# DO NOT DELETE
service xinetd start
sleep infinity;
